package com.naz.java.perlin;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class PerlinMain {

	public static void main(String[] args) {

		MultiPerlinMap.init();

		int s = 2000;
		
	//	double[] values = MultiPerlinMap.get(s, 0, 4, 0, 4);
		
		double[] values = MultiPerlinMap.getCircularPerlin(0, 0, 0.8, 3, s);
		
		values = normalize(values);
		values = normalize(values);

		for (double d : values) {
			System.out.println(d);
		}
		
		int w = s;
		int h = s/5;
		
		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_3BYTE_BGR);
		
		for(int i = 0; i < w; i++) {
			img.setRGB(i, (int)Math.min(h*values[i],h-1), Color.GREEN.getRGB());
		}
		

		String format = "png";
		File out = new File("/media/agoston/TI31462500A/linux/java/Perlin/img_"+System.currentTimeMillis()+"."+format);
		try {
			ImageIO.write(img, format, out);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static double[] normalize(double[] all) {

		double min = Double.MAX_VALUE;
		double max = Double.MIN_VALUE;

		for (double d : all) {
			max = Math.max(max, d);
			min = Math.min(min, d);
		}

		//System.out.println(max + " " + min);
		for (int i = 0; i < all.length; i++) {

			all[i] = (all[i] - min) / (max - min);

		}

		return all;

	}

}
