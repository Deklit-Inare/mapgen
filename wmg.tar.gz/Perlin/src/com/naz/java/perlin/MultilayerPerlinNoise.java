package com.naz.java.perlin;

import java.util.Random;

import com.naz.java.perlin.mechanics.PerlinNoise;

public class MultilayerPerlinNoise {
	
	public double chfreq;
	public double chsize;
	
	public PerlinNoise[] noiseLayers;
	public long[] seeds;
	
	public MultilayerPerlinNoise(double chfreq, double chsize, int layers) {
		
		noiseLayers = new PerlinNoise[layers];
		seeds = new long[layers];
		
		Random rnd = new Random();
		
		for(int i = 0; i < layers; i++) {
			
			seeds[i] = rnd.nextLong();
			noiseLayers[i] = new PerlinNoise(seeds[i]);
			
		}
		
		
	}
	
	public double get(double x, double y) {
		
		double out = 0;
		
		double freq;
		double size;
		
		for(int i = 0; i < noiseLayers.length; i++) {
			
			size = Math.pow(chsize, i);
			freq = Math.pow(chfreq, i);
			
			out += noiseLayers[i].get(x/size, y/size)*freq;
			
		}
		
		return out;
		
	}
	
}
