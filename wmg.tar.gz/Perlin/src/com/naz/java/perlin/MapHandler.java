package com.naz.java.perlin;

public class MapHandler {
	
	private MultilayerPerlinNoise mpn;
	
	public String getHeader() {
		
		
		
	}
	
	public boolean save() {
		
		try {
			
			
			
		} catch(Exception e) {
			return false;
		}
		
		return true;
		
	}
	
	public MapHandler(MultilayerPerlinNoise mpn) {
		
		this.mpn = mpn;
		
	}
	
}
