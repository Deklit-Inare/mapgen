package com.naz.java.perlin;

import com.naz.java.perlin.mechanics.PerlinNoise;

public class MultiPerlinMap {

	private static PerlinNoise[] noises;

	private static int bigN = 2;
	private static int medN = 11;
	private static int lowN = 44;

	private static double[][] mult = { new double[bigN], new double[medN], new double[lowN] };

	public static void init() {
		noises = new PerlinNoise[bigN + medN + lowN];

		for (int i = 0; i < noises.length; i++) {

			noises[i] = new PerlinNoise();

		}

	}
	
	public static double[] getCircularPerlin(double dX, double dY, double mult, double radius, int size) {
		
		double[] out = new double[size];
		
		for(int i = 0; i < size; i++) {
			
			double ratio = (double)i/(double)size;
			double alpha = ratio*mult*Math.PI*2;
			
			double x = dX + Math.cos(alpha)*radius;
			double y = dY + Math.sin(alpha)*radius;
			
			out[i] = getPerlin(x, y);
			
		}
		
		return out;
		
	}

	public static double getPerlin(double x, double y) {

		double out = 0;
		for (int cat = 0; cat < 3; cat++) {

			for (int i = 0; i < mult[cat].length; i++) {

				mult[cat][i] = 1 / (Math.pow(0.2, (cat + i / 5d)/2));
				out += toMinPlus(noises[cat * 3 + i].get(x * mult[cat][i], y * mult[cat][i]) / mult[cat][i])/50;

			}

		}

		/*
		 * for (double[] m : mult) { for (double d : m) { System.out.println(d); } }
		 */
		return out;

	}
	
	public static double toMinPlus(double x) {
		return x*2-1;
	}
	
	public static double[] get(int steps, double fromX, double toX, double fromY, double toY) {
		
		double[] out = new double[steps];
		
		for(int i = 0; i < steps; i++) {
			
			double ratio = (double)i/(double)steps;
			double x = ratio*(toX-fromX)+fromX;
			double y = ratio*(toY-fromY)+fromY;
			
			out[i] = getPerlin(x, y);
			
		}
		
		return out;
		
	}

}
