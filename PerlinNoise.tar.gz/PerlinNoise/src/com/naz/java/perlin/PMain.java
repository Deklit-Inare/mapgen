package com.naz.java.perlin;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import com.naz.java.perlin.mechanics.Colorizer;
import com.naz.java.perlin.mechanics.PerlinNoise;

public class PMain {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		long nano;
		for (int i = 0; i < 1; i++) {
			nano = System.nanoTime();
			genimg((double) i / 20d);
			System.out.println("Finished image " + i + " in "
					+ ((System.nanoTime() - nano) / 1000000000d) + " seconds.");
		}
	}

	public static double sigmoid(double x) {

		return 1 / (1 + Math.pow(Math.E, -x));

	}

	private static void genimg(double offs) throws IOException {

		int sizemult = 10;

		int w = 4320 / sizemult;
		int h = 2160 / sizemult;

		BufferedImage mmap = ImageIO.read(new File(
				"/media/sda5/knoppix/heightmaps.png"));

		BufferedImage img = new BufferedImage(w, h,
				BufferedImage.TYPE_3BYTE_BGR);

		Random rnd = new Random();

		Colorizer colorizer = getColorizer();
		
	//	colorizer.setRange(100, 102, Color.pink);
		
		PerlinNoise[] noiseList = new PerlinNoise[7     ];
		for (int i = 0; i < noiseList.length; i++) {

			noiseList[i] = new PerlinNoise(rnd.nextLong());

		}

		double mult = 0.01;

		double ampmult = 0.02;

		double ampl = 0.6;
		double size = 2.1;

		double min = 1000;
		double max = -1000;

		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {

				double gray = 0.5;
				for (int nl = 0; nl < noiseList.length; nl++) {
					gray += (noiseList[nl].get(i * mult * Math.pow(size, nl), j
							* mult * Math.pow(size, nl)) * 2 - 1)
							* Math.pow(ampl, nl) * ampmult;

				}

				/*
				 * double cent = Math.sqrt(Math.pow(i-w/2, 2)+Math.pow(j-h/2,
				 * 2)); cent = 1-cent/400 -0.5; //System.out.println(cent); cent
				 * /= 3; gray += cent;
				 */
				gray -= offs;
				gray -= 0.01;

				gray -= 0.5;

				gray *= 4.01;
				gray += 0.5;

				double worldmapmult = new Color(mmap.getRGB(i * sizemult, j
						* sizemult)).getRed() / 255d;
				// gray += 0.9*worldmapmult-.7;

				// gray = worldmapmult;
				gray -= 0.3;
				
				gray = Math.min(1, Math.max(0, gray));
				/*
				 * gray *= 0.95; gray = Math.pow(gray, 2);
				 */

				// gray = (gray - min) / (max - min);
				// System.out.println(gray);
				// gray = sigmoid((gray-.5)*8);

				// int r = (int) (gray * 255);

				// int r = (gray<0.5&&gray>0.45?255:0);

				// try{
				min = Math.min(min, gray);
				max = Math.max(max, gray);

				img.setRGB(i, j, colorizer.get(gray).getRGB());
				/*
				 * }catch(Exception e){ img.setRGB(i, j, new Color(255, 0,
				 * 255).getRGB()); }
				 */
			}
		}

		System.out.println(min * 255 + "\t" + max * 255);

		File out = new File(
				"/media/sda5/knoppix/javaimages/perlin-advanced/color/"
						+ System.currentTimeMillis() + ".png");
		out.getParentFile().mkdirs();
		try {
			ImageIO.write(img, "png", out);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static Colorizer getColorizer() {

		int vizR = 55;
		int homokR = 70;
		int hfuR = 80;
		int fuR = 170;
		int hegyR = 225;
		int hoR = 256;

		int[] ranges = { vizR, homokR, hfuR, fuR, hegyR, hoR };

		Color[] viz = { new Color(0, 0, 128), new Color(0, 55, 152), new Color(0, 60, 200),
				new Color(0, 65, 255) };
		Color[] homok = { new Color(186, 186, 93), new Color(233, 233, 117),
				new Color(244, 244, 122), new Color(255, 255, 128) };
		Color[] hfu = { new Color(128, 128, 0) };
		Color[] fu = { new Color(0, 128, 0), new Color(0, 119, 0),
				new Color(0, 128, 0), new Color(0, 157, 0) };
		Color[] hegy = { new Color(202, 172, 0), new Color(175, 125, 0),
				new Color(121, 80, 0), new Color(78, 39, 0),
				new Color(80, 60, 55), new Color(109, 88, 75) };
		Color[] ho = { new Color(195, 255, 236), new Color(220, 255, 241), new Color(255, 255, 255) };

		Color[][] colors = { viz, homok, hfu, fu, hegy, ho };

		Colorizer colorizer = new Colorizer();
		/*
		 * colorizer.setRange(0, 60, new Color(0, 0, 128)); // VIZ
		 * colorizer.setRange(60, 90, new Color(0, 55, 152));
		 * colorizer.setRange(90, 120, new Color(0, 65, 255));
		 * colorizer.setRange(120, 130, new Color(186, 186, 93)); // HOMOK
		 * colorizer.setRange(130, 140, new Color(233, 233, 117));
		 * colorizer.setRange(140, 144, new Color(255, 255, 128));
		 * colorizer.setRange(144, 150, new Color(128, 128, 0)); // HOMOK-FU
		 * colorizer.setRange(150, 160, new Color(0, 128, 0)); // FU
		 * colorizer.setRange(160, 170, new Color(0, 119, 0));
		 * colorizer.setRange(170, 180, new Color(0, 157, 0));
		 * colorizer.setRange(180, 188, new Color(118, 192, 0));
		 * colorizer.setRange(188, 192, new Color(202, 172, 0)); // HEGY
		 * colorizer.setRange(192, 202, new Color(175, 125, 0));
		 * colorizer.setRange(202, 214, new Color(121, 80, 0));
		 * colorizer.setRange(214, 222, new Color(128, 64, 0));
		 * colorizer.setRange(222, 230, new Color(78, 39, 0));
		 * colorizer.setRange(230, 240, new Color(109, 88, 75));
		 * colorizer.setRange(240, 249, new Color(195, 255, 236)); // HO
		 * colorizer.setRange(249, 256, new Color(255, 255, 255));
		 */

		int from = 0;

		for (int i = 0; i < colors.length; i++) {

			int to = ranges[i];

			for (int j = 0; j < colors[i].length; j++) {
				colorizer.setRange((int) (from + (to - from)
						* (j / (double) colors.length)), to, colors[i][j]);
			}
			from = to;

		}

		return colorizer;
	}

}
