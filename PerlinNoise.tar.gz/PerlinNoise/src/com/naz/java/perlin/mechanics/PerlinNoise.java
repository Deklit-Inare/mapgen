package com.naz.java.perlin.mechanics;

import java.util.HashMap;
import java.util.Random;

public class PerlinNoise {
	
	private long seed;

	// private HashMap<int[], Double> values = new HashMap<int[], Double>();

	public PerlinNoise(long seed) {

		this.seed = seed;

	}

	public PerlinNoise() {

		seed = new Random().nextLong();

	}
	
	public int[] last = {-1,-1};
	public double lval;

	public double get(double x, double y, double mult) {

		return get(x * mult, y * mult);

	}

	public double getWhole(int x, int y) {
		int[] vals = { x, y };
		
		if(vals[0]==last[0]&&vals[1]==last[1]){
		//	System.out.println("used");
			return lval;
		} else last = vals;
		
		//System.out.println(last[0]);
		
		// if(values.containsKey(vals)) return values.get(vals);

		Random rnd1 = new Random(x);
		Random rnd2 = new Random(y);
		Random rnd3 = new Random(seed);

		Random iterrandom = new Random(
				new Random(x).nextInt()
						+ new Random(y
								* (new Random(seed + x - y).nextBoolean() ? -1
										: 1)).nextInt()
						+ new Random(seed).nextInt());

		int maxiter = 10;

		int iter = iterrandom.nextInt(maxiter);

		for (int i = 0; i < iter; i++) {
			rnd1.nextInt();
		}

		iter = iterrandom.nextInt(maxiter);

		for (int i = 0; i < iter; i++) {
			rnd2.nextInt();
		}
		iter = iterrandom.nextInt(maxiter);

		for (int i = 0; i < iter; i++) {
			rnd3.nextInt();
		}

		double out = new Random(rnd1.nextLong() + rnd2.nextLong()
				+ rnd3.nextLong()).nextDouble();

		// values.put(vals, out);
		lval = out;
		last = vals;
		return out;

		// return Math.max(0, Math.min(1, (out-.5)*2));

		// return new Random(new Random(x).nextInt()+new Random(y*(new
		// Random(seed+x-y).nextBoolean()?-1:1)).nextInt()+new
		// Random(seed).nextInt()).nextDouble();

		// return new
		// Random(((""+seed+x).hashCode()-(""+seed+y).hashCode()+"").hashCode()).nextDouble();

	}

	public double get(double x, double y) {

		if (whole(x) && whole(y)) {

			return getWhole((int) Math.floor(x), (int) Math.floor(y));

		} else if (whole(x)) {

			double dist1 = Math.sqrt(Math.pow(y - Math.floor(y), 2));
			double dist2 = 1 - dist1;

			double c1 = getWhole((int) Math.floor(x), (int) Math.floor(y));
			double c2 = getWhole((int) Math.floor(x), (int) Math.ceil(y));

			return dist1 * c2 + dist2 * c1;

		} else if (whole(y)) {

			double dist1 = Math.sqrt(Math.pow(x - Math.floor(x), 2));
			double dist2 = 1 - dist1;

			double c1 = getWhole((int) Math.floor(x), (int) Math.floor(y));
			double c2 = getWhole((int) Math.ceil(x), (int) Math.floor(y));

			return dist1 * c2 + dist2 * c1;

		} else {

			// double xMin = Math.floor(x);
			// double xMax = Math.ceil(x);
			// double yMin = Math.floor(y);
			// double yMax = Math.ceil(y);
			//
			// double t = Math.sqrt(2);
			//
			// double dist1 = Math.sqrt(Math.pow(x-xMin, 2)+Math.pow(y-yMin,
			// 2));
			// double dist2 = Math.sqrt(Math.pow(x-xMax, 2)+Math.pow(y-yMin,
			// 2));
			// double dist3 = Math.sqrt(Math.pow(x-xMin, 2)+Math.pow(y-yMax,
			// 2));
			// double dist4 = Math.sqrt(Math.pow(x-xMax, 2)+Math.pow(y-yMax,
			// 2));
			//
			// double maxdist = Math.max(dist1, Math.max(dist2, Math.max(dist3,
			// dist4)));
			//
			// dist1 = 1-(dist1/maxdist);
			// dist2 = 1-(dist2/maxdist);
			// dist3 = 1-(dist3/maxdist);
			// dist4 = 1-(dist4/maxdist);
			//
			//
			// double c1 = getWhole((int)xMin,(int)yMin);
			// double c2 = getWhole((int)xMax,(int)yMin);
			// double c3 = getWhole((int)xMin,(int)yMax);
			// double c4 = getWhole((int)xMax,(int)yMax);
			//
			// return
			// (dist1*c1+dist2*c2+dist3*c3+dist4*c4)/(dist1+dist2+dist3+dist4);

			/*
			 * double xMin = Math.floor(x); double xMax = Math.ceil(x); double
			 * yMin = Math.floor(y); double yMax = Math.ceil(y);
			 * 
			 * double t = Math.sqrt(2);
			 * 
			 * double dist1 = 1/Math.sqrt(Math.pow(x-xMin, 2)+Math.pow(y-yMin,
			 * 2)); double dist2 = 1/Math.sqrt(Math.pow(x-xMax,
			 * 2)+Math.pow(y-yMin, 2)); double dist3 =
			 * 1/Math.sqrt(Math.pow(x-xMin, 2)+Math.pow(y-yMax, 2)); double
			 * dist4 = 1/Math.sqrt(Math.pow(x-xMax, 2)+Math.pow(y-yMax, 2));
			 * 
			 * dist1 = Math.pow(dist1, 1.5); dist2 = Math.pow(dist2, 1.5); dist3
			 * = Math.pow(dist3, 1.5); dist4 = Math.pow(dist4, 1.5);
			 * 
			 * 
			 * double c1 = getWhole((int)xMin,(int)yMin); double c2 =
			 * getWhole((int)xMax,(int)yMin); double c3 =
			 * getWhole((int)xMin,(int)yMax); double c4 =
			 * getWhole((int)xMax,(int)yMax);
			 * 
			 * // return
			 * (dist1*(c2+c3+c4)+dist2*(c1+c3+c4)+dist3*(c1+c2+c4)+dist4
			 * *(c1+c2+c3))/(dist1+dist2+dist3+dist4+10000);
			 * 
			 * return
			 * (dist1*c1+dist2*c2+dist3*c3+dist4*c4)/(dist1+dist2+dist3+dist4);
			 */

			// double xMin = Math.floor(x);
			// double xMax = Math.ceil(x);
			// double yMin = Math.floor(y);
			// double yMax = Math.ceil(y);
			//
			// double dist1x = x - xMin;
			// double dist2x = 1 -dist1x;
			//
			// double dist1y = y - yMin;
			// double dist2y = 1 -dist1y;
			//
			// double c1 = getWhole((int)xMin,(int)yMin);
			// double c2 = getWhole((int)xMax,(int)yMin);
			// double c3 = getWhole((int)xMin,(int)yMax);
			// double c4 = getWhole((int)xMax,(int)yMax);
			//
			// return (c3*dist1x+c2*dist1y+c1*dist2x+c4*dist2y)/2;

			double AX = Math.floor(x);
			double AY = Math.floor(y);
			double DX = Math.ceil(x);
			double DY = Math.ceil(y);

			double c1 = getWhole((int) AX, (int) AY);
			double c2 = getWhole((int) DX, (int) AY);
			double c3 = getWhole((int) AX, (int) DY);
			double c4 = getWhole((int) DX, (int) DY);

			double distX = x - AX;
			double distY = y - AY;

			double upperc = c1 * (1 - distX) + c2 * distX;
			double lowerc = c3 * (1 - distX) + c4 * distX;

			distY = Math.min(1, Math.max(0, distY));

			return upperc * (1 - distY) + lowerc * distY;

			// return upperc*(1-distY)+lowerc*distY;

			// double out = (c1*(1-distX)*(1-distY) + c2 * distX*(1-distY) + c3
			// * (1-distX)*distY + c4 + distX *distY);
			// System.out.println(out);

			// return Math.abs(out%1);

		}

		/*
		 * double xMin = (int)Math.floor(x); double yMin = (int)Math.floor(y);
		 * double xMax = (int)Math.ceil(x); double yMax = (int)Math.ceil(y);
		 * 
		 * 
		 * 
		 * double sq2 = Math.sqrt(2);
		 * 
		 * double c1 = getWhole((int)xMax, (int)yMax) *
		 * (Math.sqrt(Math.pow(x-xMin, 2)+Math.pow(y-yMin, 2))); double c2 =
		 * getWhole((int)xMin, (int)yMax) * (Math.sqrt(Math.pow(x-xMax,
		 * 2)+Math.pow(y-yMin, 2))); double c3 = getWhole((int)xMax, (int)yMin)
		 * * (Math.sqrt(Math.pow(x-xMin, 2)+Math.pow(y-yMax, 2))); double c4 =
		 * getWhole((int)xMin, (int)yMin) * (Math.sqrt(Math.pow(x-xMax,
		 * 2)+Math.pow(y-yMax, 2)));
		 * 
		 * return (c1+c2+c3+c4)/4;
		 */
	}

	public boolean whole(double in) {

		return in == Math.floor(in);

	}

}
