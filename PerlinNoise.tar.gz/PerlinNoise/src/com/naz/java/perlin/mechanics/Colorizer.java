package com.naz.java.perlin.mechanics;

import java.awt.Color;

public class Colorizer {
	
	public Color[] colors = new Color[256];
	
	public Colorizer() {
		
		for(int i = 0; i < colors.length; i++) {
			
			colors[i] = new Color(255, 100, 255);
			
		}
		
	}
	
	public Color get(double d) {
		
		return get((int)(d*255d));
		
	}
	
	public Color get(int in) {
		
		return colors[in];
		
	}
	
	public void setRange(int from, int to, Color c) {
		
		for(int i = from; i < to; i++) {
			
			colors[i] = c;
			
		}
		
	}
	
	
}
